from headers import *

class PowerUps:

    def __init__(self):
        self.newtime = 0
        self.total_time = 10
        self.struct = ''
        self.y_pos = 0
        self.x_pos = 0
        self.act = False

    def set_position(self, x, y):
        self.x_pos = x
        self.y_pos = y

    def activate():
        pass
    def deactivate():
        pass
    def print_powerup(self):
        if(self.y_pos != -1 or self.x_pos != -1):
            if(self.y_pos + 1 < 40):
                self.y_pos += 1
            grid[self.y_pos][self.x_pos] = self.struct

class ExpandPaddle(PowerUps):
    def __init__(self):
        PowerUps.__init__(self)
        self.struct = EXPAND_PADDLE

    def activate(self, pd):
        self.act = True
        self.newtime = round(time.time()) - round(start_time)
        if(pd.length + 6 < WIDTH-2*position-1):
            pd.length += 6
            if(pd.pos + pd.length > WIDTH-position-2):
                pd.pos -= 6

    def deactivate(self, paddle):
        self.act = -1
        paddle.length = 12

class ShrinkPaddle(PowerUps):
    def __init__(self):
        PowerUps.__init__(self)
        self.struct = SHRINK_PADDLE

    def activate(self, pd):
        self.act = True
        self.newtime = round(time.time()) - round(start_time)
        if(pd.length - 6 > 0):
            pd.length -= 6

    def deactivate(self, paddle):
        self.act = -1
        paddle.length = 12

class BallMultiplier(PowerUps):
    def __init__(self):
        PowerUps.__init__(self)
        self.struct = BALL_MULTIPLIER

    def activate(self):
        self.act = True
        self.newtime = round(time.time()) - round(start_time)
        if(pd.length - 6 > 0):
            pd.length -= 6

    def deactivate(self, paddle):
        self.act = -1
        paddle.length = 12