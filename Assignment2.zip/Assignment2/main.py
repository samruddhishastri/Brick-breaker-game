from headers import *
from paddle import *
from ball import *
from bricks import *
from powerups import *

os.system('clear')
pd = Paddle(initial_pos_pd, 15)
ball = Ball(initial_pos_ball)

initial_speed_y = -1
speed_paddle = 4

all_power_ups = [0,'e',0,'s',0]

def move_paddle():
    def alarmhandler(signum, frame):
        raise AlarmException

    def user_input(timeout=0.1):
        signal.signal(signal.SIGALRM, alarmhandler)
        signal.setitimer(signal.ITIMER_REAL, timeout)
        try:
            text = getChar()()
            signal.alarm(0)
            return text
        except AlarmException:
            signal.signal(signal.SIGALRM, signal.SIG_IGN)
            return None

    INPUT_CHAR = user_input()
    char=INPUT_CHAR

    if(ball.grab == True):
        if char == 'd':
            if(pd.pos + pd.length + speed_paddle < WIDTH-position+1):
                pd.pos += speed_paddle
                ball.pos_x += speed_paddle
            else:
                ball.pos_x += (WIDTH-position+1) - (pd.pos + pd.length)
                pd.pos += (WIDTH-position+1) - (pd.pos + pd.length)

        elif char == 'a':
            if(pd.pos-speed_paddle> position):
                pd.pos -= speed_paddle
                ball.pos_x -= speed_paddle
            else:
                ball.pos_x -= pd.pos - position
                pd.pos -= (pd.pos - position)

        elif char == ' ':
            ball.change_speed((ball.pos_x - pd.pos -(pd.length//2)-1)//2, initial_speed_y)
            ball.grab = False

        elif char == 'q':
            #os.system('clear')
            quit()
    else:
        if char == 'd':
            if(pd.pos + pd.length+speed_paddle < WIDTH-position + 1):
                pd.pos += speed_paddle
            else:
                pd.pos = WIDTH-position + 1 - pd.length

        elif char == 'a':
            if(pd.pos - speed_paddle > position):
                pd.pos -= speed_paddle
            else:
                pd.pos = position
        
        elif char == 'q':
            #os.system('clear')
            quit()

def demote_brick():
    x = ball.pos_x
    y = ball.pos_y
    vx = ball.speed_x                                                                       
    vy = ball.speed_y
    flag = 0
    x_cood = -1
    y_cood = -1
    if(vx > 0 and vy >= 0):
        for i in range(y, y+vy+1):
            for j in range(x, x+vx+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx <= 0 and vy >= 0):
        for i in range(y, y+vy+1):
            for j in range(x+vx, x+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx > 0 and vy < 0):
        for i in range(y+vy, y+1):
            for j in range(x, x+vx+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx <= 0 and vy < 0):
        for i in range(y+vy, y+1):
            for j in range(x+vx, x+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break

    if(flag == 1):
        x = brick_board[y_cood][x_cood]['x']
        y = brick_board[y_cood][x_cood]['y']
        if(brick_board[y][x]['struct'] == BRICK1):
            brick_board[y][x]['struct'] = -1
        if(brick_board[y][x]['struct'] == BRICK2):
            brick_board[y][x]['struct'] = BRICK1
        if(brick_board[y][x]['struct'] == BRICK3):
            brick_board[y][x]['struct'] = BRICK2

def ball_brick_collision(vx, x, vy, y):
    ball.change_speed(ball.speed_x, -1*ball.speed_y)

def check_collision_with_paddle():
    x = ball.pos_x
    y = ball.pos_y
    vx = ball.speed_x
    vy = ball.speed_y
    flag = 0
    if(vx > 0):
        for i in range(y, y+vy+1):
            for j in range(x, x+vx+1):
                if(grid[i][j] == PADDLE):
                    flag = 1
                    break
            if(flag==1):
                break
    else:
        for i in range(y, y+vy+1):
            for j in range(x+vx, x+1):
                if(grid[i][j] == PADDLE):
                    flag = 1
                    break
            if(flag==1):
                break

    if(flag == 1):
        return True
    else:
        return False

def check_collision_with_unbreakable_brick():
    x = ball.pos_x
    y = ball.pos_y
    vx = ball.speed_x
    vy = ball.speed_y
    flag = 0
    x_cood = -1
    y_cood = -1
    if(vx > 0 and vy >= 0):
        for i in range(y, y+vy+1):
            for j in range(x, x+vx+1):
                if(grid[i][j] == UNBREAKABLE_BRICK):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx <= 0 and vy >= 0):
        for i in range(y, y+vy+1):
            for j in range(x+vx, x+1):
                if(grid[i][j] == UNBREAKABLE_BRICK):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx > 0 and vy < 0):
        for i in range(y+vy, y+1):
            for j in range(x, x+vx+1):
                if(grid[i][j] == UNBREAKABLE_BRICK):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx <= 0 and vy < 0):
        for i in range(y+vy, y+1):
            for j in range(x+vx, x+1):
                if(grid[i][j] == UNBREAKABLE_BRICK):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break

    if(flag == 1):
        x1 = brick_board[y_cood][x_cood]['x']
        y1 = brick_board[y_cood][y_cood]['y']
        if(y+vy > y1 and y+vy < y1+3 and x > x1+12):
            return 1
        elif(y+vy > y1 and y+vy < y1+3 and x < x1):
            return 1
        else:
            return 2
    else:
        return -1

def check_collision_with_brick():
    x = ball.pos_x
    y = ball.pos_y
    vx = ball.speed_x                                                                       
    vy = ball.speed_y
    flag = 0
    x_cood = -1
    y_cood = -1
    if(vx > 0 and vy >= 0):
        for i in range(y, y+vy+1):
            for j in range(x, x+vx+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx <= 0 and vy >= 0):
        for i in range(y, y+vy+1):
            for j in range(x+vx, x+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx > 0 and vy < 0):
        for i in range(y+vy, y+1):
            for j in range(x, x+vx+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break
    elif(vx <= 0 and vy < 0):
        for i in range(y+vy, y+1):
            for j in range(x+vx, x+1):
                if(grid[i][j] == BRICK1 or grid[i][j] == BRICK2 or grid[i][j] == BRICK3):
                    flag = 1
                    x_cood = j
                    y_cood = i
                    break
            if(flag==1):
                break

    if(flag == 1):
        n = random.randint(0, len(all_power_ups)-1)
        c = all_power_ups[n]
        if(c=='e'):
            p = ExpandPaddle()
            if(ball.speed_x != 0):
                p.set_position(x, y)
            else:
                p.set_position(x+2, y)
            power_ups.append(p)
        elif(c=='s'):
            p = ShrinkPaddle()
            if(ball.speed_x != 0):
                p.set_position(x, y)
            else:
                p.set_position(x+2, y)
            power_ups.append(p)
        x1 = brick_board[y_cood][x_cood]['x']
        y1 = brick_board[y_cood][y_cood]['y']
        if(y+vy > y1 and y+vy < y1+3 and x > x1+12):
            return 1
        elif(y+vy > y1 and y+vy < y1+3 and x < x1):
            return 1
        else:
            return 2
    else:
        return -1

def check_collision():
    global score
    global lives
    if(ball.pos_x + ball.speed_x > WIDTH-position):
        ball.change_speed(-1*ball.speed_x, ball.speed_y)
    elif(ball.pos_x + ball.speed_x < position):
       ball.change_speed(-1*ball.speed_x, ball.speed_y)
    elif(ball.pos_y + ball.speed_y < 1):
       ball.change_speed(ball.speed_x, -1*ball.speed_y)
    elif(ball.pos_y + ball.speed_y > 40):
        lives -= 1
        ball.grab = True
        initial_pos_ball = random.randint(pd.pos, pd.pos+pd.length-2)
        ball.pos_x = initial_pos_ball
        ball.pos_y = 35
        ball.change_speed(0, 0)
    elif(check_collision_with_paddle() == True):
        ball.change_speed((ball.pos_x - pd.pos -(pd.length//2)-1)//2, -1*ball.speed_y)
    elif(check_collision_with_brick() != -1):
        ret = check_collision_with_brick()
        demote_brick()
        score += 1
        if(ret==1):
            ball.change_speed(-1*ball.speed_x, ball.speed_y)
        else:
            ball.change_speed(ball.speed_x, -1*ball.speed_y)
    elif(check_collision_with_unbreakable_brick() != -1):
        ret = check_collision_with_unbreakable_brick()
        if(ret==1):
            ball.change_speed(-1*ball.speed_x, ball.speed_y)
        else:
            ball.change_speed(ball.speed_x, -1*ball.speed_y)

def check_powerups():
    for i in range(len(power_ups)):
        if(power_ups[i].struct == EXPAND_PADDLE):
            if(power_ups[i].act == False):
                y = power_ups[i].y_pos
                x = power_ups[i].x_pos
                flag = 0
                for j in range(y, y+2):
                    if(grid[j][x] == PADDLE):
                        grid[j][x] = ' '
                        power_ups[i].set_position(-1, -1)
                        flag = 1
                        break

                if(flag == 1):
                    power_ups[i].activate(pd)
            elif(power_ups[i].act == True):
                if(power_ups[i].newtime + power_ups[i].total_time <= round(time.time()) - round(start_time)):
                    power_ups[i].deactivate(pd)
            
        elif(power_ups[i].struct == SHRINK_PADDLE):
            if(power_ups[i].act == False):
                y = power_ups[i].y_pos
                x = power_ups[i].x_pos
                flag = 0
                for j in range(y, y+2):
                    if(grid[j][x] == PADDLE):
                        grid[j][x] = ' '
                        power_ups[i].set_position(-1, -1)
                        flag = 1
                        break

                if(flag == 1):
                    power_ups[i].activate(pd)
            elif(power_ups[i].act == True):
                if(power_ups[i].newtime + power_ups[i].total_time <= round(time.time()) - round(start_time)):
                    power_ups[i].deactivate(pd)

create_board()
create_all_bricks()

while True:
    newtime = round(time.time()) - round(start_time)
    update_cursor(0,0)
    screen_time=time.time()
    create_ceil()
    show_bricks()
    pd.print_paddle()
    create_side_walls()
    create_floor()
    for i in range(len(power_ups)):
        power_ups[i].print_powerup()
    ball.print_ball()
    print_header(newtime, score, lives)
    print_grid()
    if(lives == 0):
        quit()
    time.sleep(0.03)
    check_powerups()
    move_paddle()
    check_collision()
    clear_grid()