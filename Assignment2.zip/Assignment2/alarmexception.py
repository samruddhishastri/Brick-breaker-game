''' This block is used to input characters from terminal '''
from __future__ import print_function


class AlarmException(Exception):
    '''This class executes the alarmexception.'''
    pass